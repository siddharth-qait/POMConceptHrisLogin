package com.qa.TestPackage;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hris.qa.base.TestBase;
import com.hris.qa.pages.HomePage;
import com.hris.qa.pages.LoginPage;

public class DemoLogin extends TestBase{
	
	LoginPage loginPg;
	HomePage homePage;
	
	
	public DemoLogin()
	{
		super();
	}
	
	@BeforeClass
	public void firstSetUp()
	{
		initialization();
	}
		
	@BeforeMethod
	public void setUp()
	{
		loginPg = new LoginPage();
	}
	
	@Test
	public void logInPageTitleTest()
	{
		String Title = loginPg.validateLoginPage();
		Assert.assertEquals(Title, "HRIS Login");
	}
	
	@Test
	public void loginPageSuccessTest()
	{
		homePage = loginPg.login(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	@AfterTest
	public void tearDown()
	{
		driver.quit();
	}

}
