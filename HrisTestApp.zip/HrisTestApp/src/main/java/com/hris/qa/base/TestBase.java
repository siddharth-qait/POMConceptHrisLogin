package com.hris.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.hris.qa.utilities.TestUtil;


public class TestBase {

	
	public static WebDriver driver;
	public static Properties prop;

	public TestBase()
	{
		
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream ("C:\\Users\\siddharthtyagi\\eclipse-workspace\\myapp\\HrisTestApp\\src\\main\\java\\com\\hris\\qa\\config\\config.properties");
		    prop.load(ip);
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}

	public static void initialization()
	
	
	{
		String browsername;
		if(System.getProperty("browser")!=null)
		{
			browsername = System.getProperty("browser");
		} else {
		browsername = prop.getProperty("browser");
		}
//		String browsername1 = prop.getProperty("browser1");
		if(browsername.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		 else if(browsername.equals("mozilla")) {
		 System.setProperty("webdriver.gecko.driver",
		 "D:\\Selenium\\geckodriver-v0.26.0-win64\\geckodriver.exe"); driver = new FirefoxDriver(); }
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT , TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
	}
}
