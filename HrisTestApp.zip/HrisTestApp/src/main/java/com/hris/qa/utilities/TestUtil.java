package com.hris.qa.utilities;

public class TestUtil {

	public static  long IMPLICIT_WAIT = 10;
}
