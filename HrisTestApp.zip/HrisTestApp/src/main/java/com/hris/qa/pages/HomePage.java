package com.hris.qa.pages;

import com.hris.qa.base.TestBase;

public class HomePage extends TestBase{

}
