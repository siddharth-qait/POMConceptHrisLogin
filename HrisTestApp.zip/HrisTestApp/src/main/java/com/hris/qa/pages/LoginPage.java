package com.hris.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hris.qa.base.TestBase;

public class LoginPage extends TestBase{
	
	//Page Factory
	
	@FindBy(name="txtUserName")
	WebElement UserName;
	
	@FindBy(name="txtPassword")
	WebElement Password;
	
	@FindBy(xpath="//input[@value='Sign In']")
	WebElement SignIn;

	public LoginPage()
	{
		PageFactory.initElements(driver, this);
		
	}
	
	public String validateLoginPage()
	{
		return driver.getTitle();
	}
	
	public HomePage login(String un, String pwd)
	{
		UserName.sendKeys(un);
		Password.sendKeys(pwd);
		SignIn.click();
		
		return new HomePage();
		
	}
	
}
